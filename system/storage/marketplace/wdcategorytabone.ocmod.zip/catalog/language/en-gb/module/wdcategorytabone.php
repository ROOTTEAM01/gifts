<?php
// Heading
$_['heading_title'] = 'Select product';