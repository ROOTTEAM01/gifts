<?php
$_['entry_sign_up_for_newsletter'] = "الاشتراك في النشرة الإخبارية";
$_['entry_newsletter'] = "Newsletter";
$_['newsub_heading'] = "متجر عضوي";
$_['button_ok'] = "Ok";
$_['button_subscribe'] = "Subscribe";
$_['default_input_text'] = "Your email address";
$_['valid_email'] = "Email is not valid!";
$_['success_post'] = "You have successfully subscribed to this newsletter.";
$_['error_post'] = "This email address is already registered.";
$_['text_description'] = "A fruit is a mature, ripened ovary, along with the contents of the ovary. The ovary is the ovule-bearing reproductive structure in the plant flower.";
$_['description_fs'] = "Get 15% off your next order. Be the first to learn about promotions special events, new arrivals and more";
$_['text_dont_show'] = "Close & Don't show this again!!!";

?>