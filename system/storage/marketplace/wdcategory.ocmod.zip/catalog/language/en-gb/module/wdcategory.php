<?php
// Heading
$_['heading_title']	= 'Wd Category';

// Text
$_['text_tax']      = 'Ex Tax:';