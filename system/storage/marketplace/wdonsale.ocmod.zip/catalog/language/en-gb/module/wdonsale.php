<?php
// Heading
$_['heading_title'] = 'WD onsale';
$_['onsalesub_heading'] = 'On Sale Products To Weekly Line Up';