<?php
// Heading
$_['heading_title'] = 'WD Top';
$_['onsalesub_heading'] = 'Top Products To Weekly Line Up';