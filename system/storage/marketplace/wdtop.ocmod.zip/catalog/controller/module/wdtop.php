<?php
namespace Opencart\Catalog\Controller\Extension\Wdtop\Module;
use \Opencart\System\Helper AS Helper;
class Wdtop extends \Opencart\System\Engine\Controller {
	public function index(array $setting): string {
		$this->load->language('extension/wdtop/module/wdtop');

		$this->load->model('catalog/product');
		$this->load->model('tool/image');

		$data['products'] = [];

		$data['special'] = $this->url->link('product/special');

		if (!empty($setting['product'])) {
			$products = [];
			$product_data = [];

			foreach ($setting['product'] as $product_id) {
				$product_info = $this->model_catalog_product->getProduct($product_id);

				if ($product_info) {
					$products[] = $product_info;
				}
			}

			foreach ($products as $product) {
				//Workdo Start
					$options = array();
					$product_id = $product['product_id'];
					foreach ($this->model_catalog_product->getOptions($product_id) as $option) {
						$product_option_value_data = array();
						foreach ($option['product_option_value'] as $option_value) {
							if (!$option_value['subtract'] || ($option_value['quantity'] > 0)) {
								if ((($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) && (float)$option_value['price']) {
									$price = $this->currency->format($this->tax->calculate($option_value['price'], $product['tax_class_id'], $this->config->get('config_tax') ? 'P' : false), $this->session->data['currency']);
									// $raw_price = $this->currency->format($this->tax->calculate($option_value['price'], $product['tax_class_id'], $this->config->get('config_tax') ? 'P' : false), $this->session->data['currency'],null,false);
								} else {
									$price = false;
									$raw_price = false;
								}
								$product_option_value_data[] = array(
									'product_option_value_id' => $option_value['product_option_value_id'],
									'option_value_id'         => $option_value['option_value_id'],
									'name'                    => $option_value['name'],
									'image'                   => $this->model_tool_image->resize($option_value['image'], 50, 50),
									'price'                   => $price,
									// 'raw_price'               => $raw_price,
									'price_prefix'            => $option_value['price_prefix']
								);						
							}
						}
						$options[] = array(
							'product_id'           => $product_id,
							'product_option_id'    => $option['product_option_id'],
							'type'                 => $option['type'],
							'product_option_value' => $product_option_value_data,
							'name'                 => $option['name'],
							'value'                => $option['value'],
							'required'             => $option['required']
						);
					}
					if (!is_null($product['special']) && (float)$product['special'] >= 0) {
						$discount = "-".round((($product['price'] - $product['special']) * 100) / $product['price'])."%";
					}
					else {
						$discount = false;
					}
				//Workdo End			
				if ($product['image']) {
					$image = $this->model_tool_image->resize(html_entity_decode($product['image'], ENT_QUOTES, 'UTF-8'), $setting['width'], $setting['height']);
				} else {
					$image = $this->model_tool_image->resize('placeholder.png', $setting['width'], $setting['height']);
				}

				if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
					$price = $this->currency->format($this->tax->calculate($product['price'], $product['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$price = false;
				}

				if ((float)$product['special']) {
					$special = $this->currency->format($this->tax->calculate($product['special'], $product['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$special = false;
				}

				if ($this->config->get('config_tax')) {
					$tax = $this->currency->format((float)$product['special'] ? $product['special'] : $product['price'], $this->session->data['currency']);
				} else {
					$tax = false;
				}

				if ($this->config->get('config_review_status')) {
					$rating = $product['rating'];
				} else {
					$rating = false;
				}

				$product_data = [
					'manufacturer'=> $product['manufacturer'],
					'manufacturer_id' => $this->url->link('product/manufacturer|info', 'manufacturer_id=' . $product['manufacturer_id']),
					'tab_review'  => $product['reviews'],
					'product_id'  => $product['product_id'],
					'options'     => $options,
					'thumb'       => $image,
					'name'        => $product['name'],
					'description' => Helper\Utf8\substr(strip_tags(html_entity_decode($product['description'], ENT_QUOTES, 'UTF-8')), 0, $this->config->get('config_product_description_length')) . '..',
					'price'       => $price,
					'special'     => $special,
					'tax'         => $tax,
					'minimum'     => $product['minimum'] > 0 ? $product['minimum'] : 1,
					'rating'      => (int)$product['rating'],
					'href'        => $this->url->link('product/product', 'language=' . $this->config->get('config_language') . '&product_id=' . $product['product_id'])
				];

				$data['products'][] = $this->load->controller('product/thumb', $product_data);
			}
		}

		if ($data['products']) {
			return $this->load->view('extension/wdtop/module/wdtop', $data);
		} else {
			return '';
		}
	}
}
