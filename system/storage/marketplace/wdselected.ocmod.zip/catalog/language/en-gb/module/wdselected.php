<?php
// Heading
$_['heading_title'] = 'WD Selected Products';
$_['onsalesub_heading'] = 'WD Selected Products To Weekly Line Up';