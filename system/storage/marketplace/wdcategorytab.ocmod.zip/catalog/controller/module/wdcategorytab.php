<?php   
namespace Opencart\Catalog\Controller\Extension\Wdcategorytab\Module;
use \Opencart\System\Helper AS Helper;
class Wdcategorytab extends \Opencart\System\Engine\Controller {
	public function index(array $setting): string {
		$this->load->language('extension/wdcategorytab/module/wdcategorytab');

		$this->load->model('catalog/category');

		$this->load->model('catalog/product');
		
		$this->load->model('tool/image');

		$data['categories'] = array();		
		if (!$setting['limit']) {
			$setting['limit'] = 4;
		}
		if (!empty($setting['category'])) {
			//$categories = array_slice($setting['category'], 0, (int)$setting['limit']);

			$categories = $setting['category'];
			$data['template_name'] = $setting['name'];
            
			foreach ($categories as $category_id) {

				$category = $this->model_catalog_category->getCategory($category_id);

				$data['category'] = $category['name'];

				$filter_data = array(
					'filter_category_id'  => $category_id,
					'filter_sub_category' => true,
					'limit'               => (int) $setting['limit'],
					'start'               => 0
				);	
							
				$category_info = $this->model_catalog_product->getProducts($filter_data);

				if ($category_info) {
					$data['products'] = array(); // сбрасываем datainfo['products'] чтобы не было дубликата
					foreach ($category_info as $key => $value) {
 						if ($value['image']) {
							$image = $this->model_tool_image->resize($value['image'], $setting['width'], $setting['height']);
						} else {
							$image = $this->model_tool_image->resize('placeholder.png', $setting['width'], $setting['height']);
						}

						if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
							$price = $this->currency->format($this->tax->calculate($value['price'], $value['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
						} else {
							$price = false;
						}

						if ((float)$value['special']) {
							$special = $this->currency->format($this->tax->calculate($value['special'], $value['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
						} else {
							$special = false;
						}						
						$product_data = [
							'manufacturer'=> $value['manufacturer'],
							'product_id'  => $value['product_id'],
							'tab_review'  => $value['reviews'],
							'thumb'       => $image,
							'name'        => $value['name'],
							'description' => Helper\Utf8\substr(strip_tags(html_entity_decode($value['description'], ENT_QUOTES, 'UTF-8')), 0, 80) . '..',
							'price'       => $price,
							'special'     => $special,
							'rating'      => $value['rating'],
							'href'        => $this->url->link('product/product', 'language=' . $this->config->get('config_language') . '&product_id=' . $value['product_id'])

						];
					

						$data['products'][] = $this->load->controller('product/thumb', $product_data);
					}
				}
				$data['categories'][] = $data;
			}
		}

		if ($data['categories']) {
			return $this->load->view('extension/wdcategorytab/module/wdcategorytab', $data);
		}
	}
}